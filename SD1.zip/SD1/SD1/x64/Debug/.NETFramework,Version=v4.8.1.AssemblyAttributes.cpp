#using <mscorlib.dll>
[assembly: System::Runtime::Versioning::TargetFrameworkAttribute(L".NETFramework,Version=v4.8.1", FrameworkDisplayName=L".NET Framework 4.8.1")];
