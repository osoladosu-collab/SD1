#pragma once
#using <Microsoft.VisualBasic.dll>

namespace SD1 {

	using namespace System;
	using namespace System::Windows::Forms;
	using namespace System::Drawing;

	public ref class MainForm : public Form
	{
	private:
		String^ cryptoKey;

	public:
		MainForm()
		{
			InitializeComponent();
			cryptoKey = "";
		}

	protected:
		~MainForm()
		{
			if (components)
				delete components;
		}

	private:
		MenuStrip^ menuStrip1;
		ToolStripMenuItem^ fileMenu;
		ToolStripMenuItem^ openItem;
		ToolStripMenuItem^ saveItem;
		ToolStripMenuItem^ exitItem;

		ToolStripMenuItem^ cryptoMenu;
		ToolStripMenuItem^ setKeyItem;
		ToolStripMenuItem^ encryptItem;
		ToolStripMenuItem^ decryptItem;

		ToolStripMenuItem^ helpMenu;
		ToolStripMenuItem^ aboutItem;

		TextBox^ textBox1;
		OpenFileDialog^ openFileDialog1;
		SaveFileDialog^ saveFileDialog1;

		System::ComponentModel::Container^ components;

#pragma region Designer
		void InitializeComponent()
		{
			menuStrip1 = gcnew MenuStrip();
			fileMenu = gcnew ToolStripMenuItem("File");
			openItem = gcnew ToolStripMenuItem("Open");
			saveItem = gcnew ToolStripMenuItem("Save");
			exitItem = gcnew ToolStripMenuItem("Exit");

			cryptoMenu = gcnew ToolStripMenuItem("Crypto");
			setKeyItem = gcnew ToolStripMenuItem("Set Key");
			encryptItem = gcnew ToolStripMenuItem("Encrypt");
			decryptItem = gcnew ToolStripMenuItem("Decrypt");

			helpMenu = gcnew ToolStripMenuItem("Help");
			aboutItem = gcnew ToolStripMenuItem("About");

			textBox1 = gcnew TextBox();
			openFileDialog1 = gcnew OpenFileDialog();
			saveFileDialog1 = gcnew SaveFileDialog();

			fileMenu->DropDownItems->Add(openItem);
			fileMenu->DropDownItems->Add(saveItem);
			fileMenu->DropDownItems->Add(exitItem);

			cryptoMenu->DropDownItems->Add(setKeyItem);
			cryptoMenu->DropDownItems->Add(encryptItem);
			cryptoMenu->DropDownItems->Add(decryptItem);

			helpMenu->DropDownItems->Add(aboutItem);

			menuStrip1->Items->Add(fileMenu);
			menuStrip1->Items->Add(cryptoMenu);
			menuStrip1->Items->Add(helpMenu);

			openItem->Click += gcnew EventHandler(this, &MainForm::OpenFile);
			saveItem->Click += gcnew EventHandler(this, &MainForm::SaveFile);
			exitItem->Click += gcnew EventHandler(this, &MainForm::ExitApp);
			aboutItem->Click += gcnew EventHandler(this, &MainForm::AboutApp);
			setKeyItem->Click += gcnew EventHandler(this, &MainForm::SetKey);
			encryptItem->Click += gcnew EventHandler(this, &MainForm::EncryptText);
			decryptItem->Click += gcnew EventHandler(this, &MainForm::DecryptText);

			textBox1->Multiline = true;
			textBox1->Dock = DockStyle::Fill;
			textBox1->ScrollBars = ScrollBars::Both;

			this->Controls->Add(textBox1);
			this->Controls->Add(menuStrip1);
			this->MainMenuStrip = menuStrip1;
			this->Text = "SD1 - Olawale Shuaib Oladosu";
			this->ClientSize = Drawing::Size(900, 600);
		}
#pragma endregion

		// ===== File =====
	private: void OpenFile(Object^, EventArgs^)
	{
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			textBox1->Text = IO::File::ReadAllText(openFileDialog1->FileName);
	}

	private: void SaveFile(Object^, EventArgs^)
	{
		if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			IO::File::WriteAllText(saveFileDialog1->FileName, textBox1->Text);
	}

	private: void ExitApp(Object^, EventArgs^)
	{
		Application::Exit();
	}

		   // ===== Help =====
	private: void AboutApp(Object^, EventArgs^)
	{
		MessageBox::Show(
			"SD1 Version 1.0\nCreated by: Olawale Shuaib Oladosu\nOrganization: VVK",
			"About SD1",
			MessageBoxButtons::OK,
			MessageBoxIcon::Information);
	}

		   // ===== Crypto =====
	private: void SetKey(Object^, EventArgs^)
	{
		cryptoKey = Microsoft::VisualBasic::Interaction::InputBox(
			"Enter encryption key:", "Set Key", "", -1, -1);

		if (cryptoKey == "")
			MessageBox::Show("Key cannot be empty!");
		else
			MessageBox::Show("Key set successfully.");
	}

	private: String^ XOREncryptDecrypt(String^ text, String^ key)
	{
		if (key->Length == 0) return text;

		array<wchar_t>^ buffer = text->ToCharArray();
		for (int i = 0; i < buffer->Length; i++)
			buffer[i] = buffer[i] ^ key[i % key->Length];

		return gcnew String(buffer);
	}

	private: void EncryptText(Object^, EventArgs^)
	{
		if (cryptoKey == "") { MessageBox::Show("Set a key first."); return; }
		textBox1->Text = XOREncryptDecrypt(textBox1->Text, cryptoKey);
	}

	private: void DecryptText(Object^, EventArgs^)
	{
		if (cryptoKey == "") { MessageBox::Show("Set a key first."); return; }
		textBox1->Text = XOREncryptDecrypt(textBox1->Text, cryptoKey);
	}

	};
}
