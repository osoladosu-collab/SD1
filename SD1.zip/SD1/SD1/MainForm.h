#pragma once
#using <Microsoft.VisualBasic.dll>

namespace SD1 {

	using namespace System;
	using namespace System::Windows::Forms;
	using namespace System::Drawing;

	public ref class MainForm : public Form
	{
	private:
		String^ cryptoKey;

	public:
		MainForm()
		{
			InitializeComponent();
			cryptoKey = "";
		}

	protected:
		~MainForm()
		{
			if (components)
				delete components;
		}

	private:
		MenuStrip^ menuStrip1;
		ToolStripMenuItem^ fileMenu;
		ToolStripMenuItem^ openItem;
		ToolStripMenuItem^ saveItem;
		ToolStripMenuItem^ exitItem;

		ToolStripMenuItem^ cryptoMenu;
		ToolStripMenuItem^ setKeyItem;
		ToolStripMenuItem^ encryptItem;
		ToolStripMenuItem^ decryptItem;

		ToolStripMenuItem^ helpMenu;
		ToolStripMenuItem^ aboutItem;

		TextBox^ textBox1;
		OpenFileDialog^ openFileDialog1;
		SaveFileDialog^ saveFileDialog1;
	private: System::Windows::Forms::MenuStrip^ menuStrip2;
	private: System::Windows::Forms::MenuStrip^ menuStrip3;


		System::ComponentModel::Container^ components;

#pragma region Designer
		void InitializeComponent()
		{
			this->menuStrip2 = (gcnew System::Windows::Forms::MenuStrip());
			this->menuStrip3 = (gcnew System::Windows::Forms::MenuStrip());
			this->SuspendLayout();
			// 
			// menuStrip2
			// 
			this->menuStrip2->GripMargin = System::Windows::Forms::Padding(2, 2, 0, 2);
			this->menuStrip2->ImageScalingSize = System::Drawing::Size(28, 28);
			this->menuStrip2->Location = System::Drawing::Point(0, 42);
			this->menuStrip2->Name = L"menuStrip2";
			this->menuStrip2->Size = System::Drawing::Size(1012, 42);
			this->menuStrip2->TabIndex = 0;
			this->menuStrip2->Text = L"menuStrip2";
			// 
			// menuStrip3
			// 
			this->menuStrip3->GripMargin = System::Windows::Forms::Padding(2, 2, 0, 2);
			this->menuStrip3->ImageScalingSize = System::Drawing::Size(28, 28);
			this->menuStrip3->Location = System::Drawing::Point(0, 0);
			this->menuStrip3->Name = L"menuStrip3";
			this->menuStrip3->Size = System::Drawing::Size(1012, 42);
			this->menuStrip3->TabIndex = 1;
			this->menuStrip3->Text = L"menuStrip3";
			// 
			// MainForm
			// 
			this->ClientSize = System::Drawing::Size(1012, 706);
			this->Controls->Add(this->menuStrip2);
			this->Controls->Add(this->menuStrip3);
			this->MainMenuStrip = this->menuStrip2;
			this->Name = L"MainForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		// ===== File =====
	private: void OpenFile(Object^, EventArgs^)
	{
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			textBox1->Text = IO::File::ReadAllText(openFileDialog1->FileName);
	}

	private: void SaveFile(Object^, EventArgs^)
	{
		if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			IO::File::WriteAllText(saveFileDialog1->FileName, textBox1->Text);
	}

	private: void ExitApp(Object^, EventArgs^)
	{
		Application::Exit();
	}

		   // ===== Help =====
	private: void AboutApp(Object^, EventArgs^)
	{
		MessageBox::Show(
			"SD1 Version 1.0\nCreated by: Olawale Shuaib Oladosu\nOrganization: VVK",
			"About SD1",
			MessageBoxButtons::OK,
			MessageBoxIcon::Information);
	}

		   // ===== Crypto =====
	private: void SetKey(Object^, EventArgs^)
	{
		cryptoKey = Microsoft::VisualBasic::Interaction::InputBox(
			"Enter encryption key:", "Set Key", "", -1, -1);

		if (cryptoKey == "")
			MessageBox::Show("Key cannot be empty!");
		else
			MessageBox::Show("Key set successfully.");
	}

	private: String^ XOREncryptDecrypt(String^ text, String^ key)
	{
		if (key->Length == 0) return text;

		array<wchar_t>^ buffer = text->ToCharArray();
		for (int i = 0; i < buffer->Length; i++)
			buffer[i] = buffer[i] ^ key[i % key->Length];

		return gcnew String(buffer);
	}

	private: void EncryptText(Object^, EventArgs^)
	{
		if (cryptoKey == "") { MessageBox::Show("Set a key first."); return; }
		textBox1->Text = XOREncryptDecrypt(textBox1->Text, cryptoKey);
	}

	private: void DecryptText(Object^, EventArgs^)
	{
		if (cryptoKey == "") { MessageBox::Show("Set a key first."); return; }
		textBox1->Text = XOREncryptDecrypt(textBox1->Text, cryptoKey);
	}

	};
}
