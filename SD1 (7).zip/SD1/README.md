# StudentJournalGUI_SD1_CPP
StudentJournalGUI SD1 v1.0 – A C++ Windows Forms application with file handling, encryption/decryption, and a custom installer (VVK).
