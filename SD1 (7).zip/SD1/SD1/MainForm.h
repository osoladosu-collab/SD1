﻿#pragma once

#using <System.dll>
#using <System.Windows.Forms.dll>
#using <System.Drawing.dll>

using namespace System;
using namespace System::IO;
using namespace System::Text;
using namespace System::Drawing;
using namespace System::Windows::Forms;

namespace StudentJournalGUI_SD1_CPP {

    public ref class MainForm : public Form
    {
    public:
        MainForm()
        {
            InitializeComponent();

            encryptionKey = "1234";

            this->Text = "StudentJournalGUI-SD1 v1.0";
            this->StartPosition = FormStartPosition::CenterScreen;
            this->MinimumSize = Drawing::Size(800, 600);

            txtMain->Multiline = true;
            txtMain->ScrollBars = ScrollBars::Both;
            txtMain->WordWrap = false;
            txtMain->Dock = DockStyle::Fill;
        }

    private:
        // ===== UI =====
        MenuStrip^ menuStrip1;

        ToolStripMenuItem^ fileMenu;
        ToolStripMenuItem^ openItem;
        ToolStripMenuItem^ saveItem;
        ToolStripMenuItem^ exitItem;

        ToolStripMenuItem^ securityMenu;
        ToolStripMenuItem^ setKeyItem;
        ToolStripMenuItem^ encryptSaveItem;
        ToolStripMenuItem^ openDecryptItem;

        ToolStripMenuItem^ helpMenu;
        ToolStripMenuItem^ aboutItem;

        TextBox^ txtMain;

        // ===== Data =====
        String^ encryptionKey;

        // ===== XOR helper (encrypt/decrypt) =====
        array<Byte>^ XorBytes(array<Byte>^ data)
        {
            if (String::IsNullOrEmpty(encryptionKey))
                encryptionKey = "1234";

            array<Byte>^ keyBytes = Encoding::UTF8->GetBytes(encryptionKey);
            array<Byte>^ result = gcnew array<Byte>(data->Length);

            for (int i = 0; i < data->Length; i++)
                result[i] = (Byte)(data[i] ^ keyBytes[i % keyBytes->Length]);

            return result;
        }

        // ===== Key input dialog (pure WinForms) =====
        bool PromptForKey()
        {
            Form^ dlg = gcnew Form();
            dlg->Text = "Set Key";
            dlg->StartPosition = FormStartPosition::CenterParent;
            dlg->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog; // ✅ FIXED
            dlg->MinimizeBox = false;
            dlg->MaximizeBox = false;
            dlg->ShowInTaskbar = false;
            dlg->Width = 420;
            dlg->Height = 170;

            Label^ lbl = gcnew Label();
            lbl->Text = "Enter encryption key:";
            lbl->Left = 12;
            lbl->Top = 15;
            lbl->AutoSize = true;

            TextBox^ tb = gcnew TextBox();
            tb->Left = 15;
            tb->Top = 40;
            tb->Width = 370;
            tb->Text = encryptionKey;

            Button^ ok = gcnew Button();
            ok->Text = "OK";
            ok->Left = 230;
            ok->Top = 80;
            ok->Width = 75;
            ok->DialogResult = System::Windows::Forms::DialogResult::OK;

            Button^ cancel = gcnew Button();
            cancel->Text = "Cancel";
            cancel->Left = 310;
            cancel->Top = 80;
            cancel->Width = 75;
            cancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;

            dlg->Controls->Add(lbl);
            dlg->Controls->Add(tb);
            dlg->Controls->Add(ok);
            dlg->Controls->Add(cancel);

            dlg->AcceptButton = ok;
            dlg->CancelButton = cancel;

            auto res = dlg->ShowDialog(this);
            if (res == System::Windows::Forms::DialogResult::OK)
            {
                if (!String::IsNullOrWhiteSpace(tb->Text))
                {
                    encryptionKey = tb->Text;
                    MessageBox::Show("Key updated.", "Security",
                        MessageBoxButtons::OK, MessageBoxIcon::Information);
                    return true;
                }

                MessageBox::Show("Key cannot be empty.", "Security",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return false;
            }
            return false;
        }

        // ===== Build UI =====
        void InitializeComponent()
        {
            menuStrip1 = gcnew MenuStrip();

            fileMenu = gcnew ToolStripMenuItem("File");
            openItem = gcnew ToolStripMenuItem("Open...");
            saveItem = gcnew ToolStripMenuItem("Save As...");
            exitItem = gcnew ToolStripMenuItem("Exit");

            securityMenu = gcnew ToolStripMenuItem("Security");
            setKeyItem = gcnew ToolStripMenuItem("Set Key...");
            encryptSaveItem = gcnew ToolStripMenuItem("Encrypt & Save...");
            openDecryptItem = gcnew ToolStripMenuItem("Open & Decrypt...");

            helpMenu = gcnew ToolStripMenuItem("Help");
            aboutItem = gcnew ToolStripMenuItem("About");

            txtMain = gcnew TextBox();

            // Menu structure
            fileMenu->DropDownItems->Add(openItem);
            fileMenu->DropDownItems->Add(saveItem);
            fileMenu->DropDownItems->Add(exitItem);

            securityMenu->DropDownItems->Add(setKeyItem);
            securityMenu->DropDownItems->Add(encryptSaveItem);
            securityMenu->DropDownItems->Add(openDecryptItem);

            helpMenu->DropDownItems->Add(aboutItem);

            menuStrip1->Items->Add(fileMenu);
            menuStrip1->Items->Add(securityMenu);
            menuStrip1->Items->Add(helpMenu);

            // Events
            openItem->Click += gcnew EventHandler(this, &MainForm::OnOpen);
            saveItem->Click += gcnew EventHandler(this, &MainForm::OnSaveAs);
            exitItem->Click += gcnew EventHandler(this, &MainForm::OnExit);

            setKeyItem->Click += gcnew EventHandler(this, &MainForm::OnSetKey);
            encryptSaveItem->Click += gcnew EventHandler(this, &MainForm::OnEncryptSave);
            openDecryptItem->Click += gcnew EventHandler(this, &MainForm::OnOpenDecrypt);

            aboutItem->Click += gcnew EventHandler(this, &MainForm::OnAbout);

            // Controls
            this->Controls->Add(txtMain);
            this->Controls->Add(menuStrip1);
            this->MainMenuStrip = menuStrip1;
        }

        // ===== File -> Open =====
        void OnOpen(Object^ sender, EventArgs^ e)
        {
            OpenFileDialog^ ofd = gcnew OpenFileDialog();
            ofd->Title = "Open text file";
            ofd->Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (ofd->ShowDialog() == System::Windows::Forms::DialogResult::OK)
                txtMain->Text = File::ReadAllText(ofd->FileName, Encoding::UTF8);
        }

        // ===== File -> Save As =====
        void OnSaveAs(Object^ sender, EventArgs^ e)
        {
            SaveFileDialog^ sfd = gcnew SaveFileDialog();
            sfd->Title = "Save text file";
            sfd->Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            sfd->FileName = "result.txt";

            if (sfd->ShowDialog() == System::Windows::Forms::DialogResult::OK)
                File::WriteAllText(sfd->FileName, txtMain->Text, Encoding::UTF8);
        }

        // ===== Exit =====
        void OnExit(Object^ sender, EventArgs^ e)
        {
            this->Close();
        }

        // ===== Security -> Set Key =====
        void OnSetKey(Object^ sender, EventArgs^ e)
        {
            PromptForKey();
        }

        // ===== Security -> Encrypt & Save =====
        void OnEncryptSave(Object^ sender, EventArgs^ e)
        {
            if (String::IsNullOrWhiteSpace(encryptionKey))
            {
                MessageBox::Show("Please set a key first (Security -> Set Key).", "Security",
                    MessageBoxButtons::OK, MessageBoxIcon::Information);
                return;
            }

            SaveFileDialog^ sfd = gcnew SaveFileDialog();
            sfd->Title = "Encrypt & Save";
            sfd->Filter = "Encrypted files (*.enc)|*.enc|All files (*.*)|*.*";
            sfd->FileName = "result.enc";

            if (sfd->ShowDialog() == System::Windows::Forms::DialogResult::OK)
            {
                array<Byte>^ plain = Encoding::UTF8->GetBytes(txtMain->Text);
                array<Byte>^ enc = XorBytes(plain);
                File::WriteAllBytes(sfd->FileName, enc);

                MessageBox::Show("Encrypted file saved.", "Security",
                    MessageBoxButtons::OK, MessageBoxIcon::Information);
            }
        }

        // ===== Security -> Open & Decrypt =====
        void OnOpenDecrypt(Object^ sender, EventArgs^ e)
        {
            if (String::IsNullOrWhiteSpace(encryptionKey))
            {
                MessageBox::Show("Please set a key first (Security -> Set Key).", "Security",
                    MessageBoxButtons::OK, MessageBoxIcon::Information);
                return;
            }

            OpenFileDialog^ ofd = gcnew OpenFileDialog();
            ofd->Title = "Open & Decrypt";
            ofd->Filter = "Encrypted files (*.enc)|*.enc|All files (*.*)|*.*";

            if (ofd->ShowDialog() == System::Windows::Forms::DialogResult::OK)
            {
                array<Byte>^ enc = File::ReadAllBytes(ofd->FileName);
                array<Byte>^ plain = XorBytes(enc);
                txtMain->Text = Encoding::UTF8->GetString(plain);

                MessageBox::Show("File decrypted and loaded.", "Security",
                    MessageBoxButtons::OK, MessageBoxIcon::Information);
            }
        }

        // ===== Help -> About =====
        void OnAbout(Object^ sender, EventArgs^ e)
        {
            MessageBox::Show(
                "StudentJournalGUI-SD1\n"
                "Version 1.0\n\n"
                "A Windows Forms application for reading, editing,\n"
                "saving and encrypting text files.\n\n"
                "Author: Olawale Shuaib Oladosu\n"
                "Organization: VVK\n"
                "Year: 2026",
                "About",
                MessageBoxButtons::OK,
                MessageBoxIcon::Information
            );
        }
    };
}
